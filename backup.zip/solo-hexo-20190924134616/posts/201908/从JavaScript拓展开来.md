title: 从JavaScript拓展开来。。。
date: '2019-08-13 20:08:12'
updated: '2019-08-13 20:08:29'
tags: [javascript, nodejs]
permalink: /articles/2019/08/13/1565698092059.html
---
## JavaScript诞生
1994年，网景公司（Netscape）发布了Navigator浏览器0.9版。这是历史上第一个比较成熟的网络浏览器，轰动一时。但是，这个版本的浏览器只能用来浏览，不具备与访问者互动的能力。比如，如果网页上有一栏"用户名"要求填写，浏览器就无法判断访问者是否真的填写了，只有让服务器端判断。如果没有填写，服务器端就返回错误，要求用户重新填写，这太浪费时间和服务器资源了。  
     因此，网景公司急需一种网页脚本语言，潜入到网页中，使得浏览器可以与网页互动。网页脚本语言到底是什么语言？网景公司当时有两个选择：一个是采用现有的语言，比如Perl、Python、Tcl、Scheme等等，允许它们直接嵌入网页；另一个是发明一种全新的语言。这两个选择各有利弊。第一个选择，有利于充分利用现有代码和程序员资源，推广起来比较容易；第二个选择，有利于开发出完全适用的语言，实现起来比较容易。到底采用哪一个选择，网景公司内部争执不下，管理层一时难以下定决心。

    就在这时，发生了另外一件大事：1995年Sun公司将Oak语言改名为Java，正式向市场推出。  
Sun公司大肆宣传，许诺这种语言可以"一次编写，到处运行"（Write Once, Run Anywhere），它看上去很可能成为未来的主宰。网景公司动了心，决定与Sun公司结成联盟。它不仅允许Java程序以applet（小程序）的形式，直接在浏览器中运行；甚至还考虑直接将Java作为脚本语言嵌入网页，只是因为这样会使HTML网页过于复杂，后来才不得不放弃。总之，当时的形势就是，网景公司的整个管理层，都是Java语言的信徒，Sun公司完全介入网页脚本语言的决策。因此，Javascript后来就是网景和Sun两家公司一起携手推向市场的，这种语言被命名为"Java+script"并不是偶然的。

    1995年4月，网景公司录用了34岁的系统程序员Brendan Eich。Brendan Eich的主要方向和兴趣是函数式编程，网景公司招聘他的目的，是研究将Scheme语言作为网页脚本语言的可能性。Brendan Eich本人也是这样想的，以为进入新公司后，会主要与Scheme语言打交道。但仅仅一个月之后，1995年5月，网景公司做出决策，未来的网页脚本语言必须"看上去与Java足够相似"，但是比Java简单，使得非专业的网页作者也能很快上手。这个决策实际上将Perl、Python、Tcl、Scheme等非面向对象编程的语言都排除在外了。Brendan Eich被指定为这种"简化版Java语言"的设计师。  
    但是，他对Java一点兴趣也没有。为了应付公司安排的任务，他只用10天时间就把Javascript设计出来了。由于设计时间太短，语言的一些细节考虑得不够严谨，导致后来很长一段时间，Javascript写出来的程序混乱不堪。

  总的来说，他的设计思路是这样的：  
　　（1）借鉴C语言的基本语法；  
　　（2）借鉴Java语言的数据类型和内存管理；  
　　（3）借鉴Scheme语言，将函数提升到"第一等公民"（first class）的地位；  
　　（4）借鉴Self语言，使用基于原型（prototype）的继承机制。  
所以，Javascript语言实际上是两种语言风格的混合产物----（简化的）函数式编程+（简化的）面向对象编程。这是由Brendan Eich（函数式编程）与网景公司（面向对象编程）共同决定的。

     Brendan Eich设计的这个脚本语言，是为Netscape公司准备在1995年发行的 Netscape Navigator 2.0 浏览器提供的。 开始的时候这个语言是被称为LiveScript，就在 Netscape Navigator 2.0 即将正式发布前，Netscape 将其更名为 JavaScript，目的是为了利用 Java 这个因特网时髦词汇。这个是 JavaScript 1.0 版本。该版本推出，获得了很大成功。  
    因为 JavaScript 1.0 如此成功，Netscape 在 Netscape Navigator 3.0 中发布了 1.1 版。恰巧那个时候，微软决定进军浏览器，发布了 IE 3.0 并搭载了一个 JavaScript 的克隆版，叫做 JScript（这样命名是为了避免与 Netscape 潜在的许可纠纷）。微软步入 Web 浏览器领域的这重要一步虽然令其声名狼藉，但也成为 JavaScript 语言发展过程中的重要一步。  
　　在微软进入后，有 3 种不同的 JavaScript 版本同时存在：Netscape Navigator 3.0 中的 JavaScript、IE 中的 JScript 以及 CEnvi 中的 ScriptEase（一家称作 Nombas 的公司开发的可嵌入网页的脚本语言）。与 C 和其他编程语言不同的是，JavaScript 并没有一个标准来统一其语法或特性，而这 3 种不同的版本恰恰突出了这个问题。随着业界担心的增加，这个语言的标准化显然已经势在必行。

## ECMAScript的诞生

     1996年11月，JavaScript的创造者Netscape公司，决定将JavaScript提交给国际标准化组织ECMA，希望这种语言能够成为国际标准。ECMA是European Computer Manufacturers Association的缩写，即欧洲计算机制造商协会，ECMA是制定信息传输与通讯的国际化标准组织。    ECMA的第39号技术专家委员会（Technical Committee 39，简称TC39）负责制订ECMAScript标准，成员包括Netscape、Sun、Microsoft、Mozilla、Google等大公司。  
   1997年，ECMA发布262号标准文件（ECMA-262）的第一版，规定了浏览器脚本语言的标准，并将这种语言称为ECMAScript，这个版本就是1.0版。   该标准从一开始就是针对JavaScript语言制定的，但是之所以不叫JavaScript，有两个原因。一是商标，Java是Sun公司的商标，根据授权协议，只有Netscape公司可以合法地使用JavaScript这个名字，且JavaScript本身也已经被Netscape公司注册为商标。二是想体现这门语言的制定者是ECMA，不是Netscape，这样有利于保证这门语言的开放性和中立性。  
   **因此，ECMAScript和JavaScript的关系是，前者是后者的规格，后者是前者的一种实现。Jscript和ActionScript也算是ECMAScript的一种实现**。

## ECMAScript的发展

1997年，ECMAScript 1.0发布。
1998年，ECMAScript 2.0发布
1999年，ECMAScript 3.0发布。3.0版是一个巨大的成功，在业界得到广泛支持，成为通行标准，奠定了JavaScript语言的基本语法，以后的版本完全继承。直到今天，初学者一开始学习JavaScript，其实就是在学3.0版的语法。
2000年，ECMAScript 4.0开始酝酿。这个版本最后没有通过。为什么ES4没有通过呢？因为这个版本太激进了，对ES3做了彻底升级，导致标准委员会的一些成员不愿意接受。
2007年，ECMAScript 4.0版草案发布，本来预计次年8月发布正式版本。但是，各方对于是否通过这个标准，发生了严重分歧。以Yahoo、Microsoft、Google为首的大公司，反对JavaScript的大幅升级，主张小幅改动；以JavaScript创造者Brendan Eich为首的Mozilla公司，则坚持当前的草案。
2008年，由于对于4.0版本应该包括哪些功能，各方分歧太大，争论过于激烈，ECMA开会决定，中止ECMAScript 4.0的开发，将其中涉及现有功能改善的一小部分，发布为ECMAScript 3.1（会后不久，ECMAScript 3.1就改名为ECMAScript 5），而将其他激进的设想扩大范围，放入以后的版本。由于会议的气氛，4.0版本的项目代号起名为Harmony（和谐）。
2009年，ECMAScript 5.0版正式发布。Harmony项目则一分为二，一些较为可行的设想定名为JavaScript.next继续开发，后来演变成ECMAScript 6；一些不是很成熟的设想，则被视为JavaScript.next.next，在更远的将来再考虑推出。
2011年，ECMAscript 5.1版发布，并且成为ISO国际标准。
2013年3月，ECMAScript 6草案冻结，不再添加新功能。
2013年12月，ECMAScript 6草案发布。
2015年6月，ECMAScript 6正式通过，成为国际标准。从2000年算起，这时已经过去了15年。
ECMAScript 6 提出了很多新的特性，重点加强了模块、类声明、词法块定界、迭代器和生成器、异步编程的回调、模式解析以及合适的尾调用，另外还扩展了ECMAScript的内置库以支持更多的抽象数据结构。其目的就是使JavaScript可以用来编写复杂的应用程序，成为企业级开发语言。

## commonJs诞生

    在JavaScript的发展历程中，它主要在浏览器前端发光发热。由于官方规范（ECMAScript）规范化的时间较早，规范涵盖的范畴非常小。这些规范中包含词法、类型、上下文、表达式、声明（statement）、方法、对象等语言的基本要素。在实际应用中，JavaScript的表现能力取决于宿主环境中的API支持程度。  
   1）在Web 1.0时代，只有对DOM、BOM等基本的支持。  
   2）随着Web 2.0的推进，HTML5崭露头角，它将Web网页带进Web应用的时代，在浏览器中出现了更多、更强大的API供JavaScript调用。

    但是，对于JavaScript自身而言，它的规范依然是薄弱的，还有很多缺陷，如没有模块系统（在ECMAScript 6解决了）；标准库较少。ECMAScript仅定义了部分核心库，对于文件系统，I/O流，数据库访问等常见需求却没有标准的API，导致它无法用在后端开发。


* JavaScript 没有模块系统。没有原生的支持密闭作用域或依赖管理。
* JavaScript 没有标准库。除了一些核心库外，没有文件系统的 API，没有 IO 流 API 等。
* JavaScript 没有标准接口。没有如 Web Server 或者数据库的统一接口。

* JavaScript 没有包管理系统。不能自动加载和安装依赖。  

     在js发展的过程中，社区也在为JavaScript制定了相应的规范，其中CommonJS规范的提出算是最为重要的里程碑。在2009年8月，CommonJS诞生了。CommonJS规范为JavaScript制定了一个美好的愿景——希望JavaScript能够在任何地方运行。以达到像Python、Ruby和Java具备开发大型应用的基础能力，而不是停留在小脚本程序的阶段。

     他们期望那些用CommonJS API写出的应用可以具备跨宿主环境执行的能力，这样不仅可以利用JavaScript开发富客户端应用，而且还可以编写以下应用，如服务器端JavaScript应用程序；命令行工具；桌面图形界面应用程序。 如今，CommonJS中的大部分规范虽然依旧是草案，但是已经初显成效，为JavaScript开发大型应用程序指明了一条非常棒的道路。目前，它依旧在成长中，这些规范涵盖了模块、二进制、Buffer、字符集编码、I/O流、进程环境、文件系统、套接字、单元测试、Web服务器网关接口、包管理等。  
  **CommonJS是一种规范，业界有很多它的实现，其中最著名的是node.js，另外还有Apache的CouchDB等。**

## 附录
Ecmascript 是一个脚本语言标准，规定这个语言的语法，内置函数等等 Javascript是Ecmascript标准的一个实现，简称 js
脚本语言本身是文件文件，不能像exe那样直接执行，它要执行需要一个宿主环境，比如浏览器，它提供给js一个window对象和document对象，可以供js操作
或者在windows下直接双击.js文件，它是在Jscript宿主下执行的，如果js文件是针对浏览器写的，双击执行一般会直接报错
nodejs是javascript的一个web服务器宿主，编写脚本可以直接创建一个web服务器监听访问，然后作一些数据操作和输出。
nodejs里有个包管理器叫nmp  一般安装nodejs是为了用它这个包管理器，可以管理很多js实现的功能包
react是基于js的二次解析引擎，它支持在js里直接穿插html代码(有一定的规则要求)，然后解析成正常的js代码并执行。
react native是基于js和react js的一个开发环境，可以直接用两者的语法开发并编译出原生APP
