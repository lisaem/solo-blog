title: 博客文章没同步到社区，看到 log 中有一个报错，只是链接关闭的，发生文章是成功的了。。。
date: '2019-08-11 19:55:18'
updated: '2019-08-11 19:55:18'
tags: [反馈]
permalink: /articles/2019/08/11/1564300485789.html
---
[ERROR]-[2019-07-28 15:17:00]-[org.b3log.latke.servlet.renderer.StaticFileRenderer:56]: Default servlet forward error
org.eclipse.jetty.io.EofException
        at org.eclipse.jetty.io.ChannelEndPoint.flush(ChannelEndPoint.java:286)
        at org.eclipse.jetty.io.WriteFlusher.flush(WriteFlusher.java:393)
        at org.eclipse.jetty.io.WriteFlusher.completeWrite(WriteFlusher.java:349)
        at org.eclipse.jetty.io.ChannelEndPoint$3.run(ChannelEndPoint.java:133)
        at org.eclipse.jetty.util.thread.strategy.EatWhatYouKill.runTask(EatWhatYouKill.java:333)
        at org.eclipse.jetty.util.thread.strategy.EatWhatYouKill.doProduce(EatWhatYouKill.java:295)
        at org.eclipse.jetty.util.thread.strategy.EatWhatYouKill.tryProduce(EatWhatYouKill.java:168)
        at org.eclipse.jetty.util.thread.strategy.EatWhatYouKill.run(EatWhatYouKill.java:126)
        at org.eclipse.jetty.util.thread.ReservedThreadExecutor$ReservedThread.run(ReservedThreadExecutor.java:366)
        at org.eclipse.jetty.util.thread.QueuedThreadPool.runJob(QueuedThreadPool.java:765)
        at org.eclipse.jetty.util.thread.QueuedThreadPool$2.run(QueuedThreadPool.java:683)
        at java.lang.Thread.run(Thread.java:748)
Caused by: java.io.IOException: Broken pipe
        at sun.nio.ch.FileDispatcherImpl.write0(Native Method)
        at sun.nio.ch.SocketDispatcher.write(SocketDispatcher.java:47)
        at sun.nio.ch.IOUtil.writeFromNativeBuffer(IOUtil.java:93)
        at sun.nio.ch.IOUtil.write(IOUtil.java:51)
        at sun.nio.ch.SocketChannelImpl.write(SocketChannelImpl.java:471)
        at org.eclipse.jetty.io.ChannelEndPoint.flush(ChannelEndPoint.java:264)
        ... 11 more
[INFO ]-[2019-07-28 15:19:34]-[org.b3log.solo.processor.console.ArticleConsole:495]: Updates an article request [{"article":{"articleTitle":"Linux目录结构详细介绍","postToCommunity":true,"articleViewPwd":"","articleCommentable":true,"articleStatus":0,"articleContent":"目录\n\n1、树状目录结构图\n\n2、/目录\n\n3、/etc/目录\n\n4、/usr/目录\n\n5、/var/目录\n\n6、/proc/目录\n\n7、/dev/目录\n\n下面红色字体为比较重要的目录\n\n先说明一些bin目录的区别\n\n/usr/bin下面的都是系统预装的可执行程序，会随着系统升级而改变\n\n/usr/local/bin目录是给用户放置自己的可执行程序的地方，推荐放在这里，不会被系统升级而覆盖同名文件\n\n/bin放置的是在单用户维护模式下还能够被操作的命令，在/bin下面的命令可以被root和一般账号使用，主要有cat，chmod，chown，cpmkdir等常用命令。系统启动后挂载到根文件系统中的。\n\n/sbin 下的命令属于基本的系统命令，如shutdown，reboot，用于设置设置系统环境，如开机，修复系统。/sbin下的命令只有root才能使用系统启动后挂载到根文件系统中的。\n","articleSignId":"1","articleTags":"test","oId":"1564297999074","articleAbstract":"","articlePermalink":"/articles/2019/07/28/1564297999074.html"}}]
[INFO ]-[2019-07-28 15:19:35]-[org.b3log.solo.event.B3ArticleSender:130]: Pushed an article [title=Linux目录结构详细介绍] to Rhy, response [HTTP/1.1 200 OK
Connection: close
Content-Length: 60
Content-Type: application/json; charset=UTF-8
Date: Sun, 28 Jul 2019 07:19:35 GMT
Server: nginx/1.15.3

{"msg":"Post an article successfully","code":0,"succ":true}
]