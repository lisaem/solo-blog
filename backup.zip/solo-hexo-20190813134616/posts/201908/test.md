title: test
date: '2019-08-11 19:42:46'
updated: '2019-08-11 19:46:06'
tags: [test]
permalink: /articles/2019/08/11/1565523765992.html
---
```
user  nginx;
worker_processes  1;

error_log  /var/log/nginx/error.log warn;
pid        /var/run/nginx.pid;


events {
    worker_connections  1024;
}


http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile        on;
    #tcp_nopush     on;

    keepalive_timeout  65;

    #gzip  on;

upstream backend {
server www.o519.com:28808;
}

server {
listen       443;  # 修改监听接口
server_name  o519.com  www.o519.com;
charset utf8; # 修改默认字符
ssl on;  # 开启ssl

# 很重要！！！设定你的ssl证书
ssl_certificate /etc/nginx/www.o519.com.pem;
ssl_certificate_key /etc/nginx/www.o519.com.key;

# 重要！ 原有的接口代理可以不用修改，在内部使用http
location / {
proxy_pass http://backend$request_uri;
proxy_set_header  Host $host:$server_port;
proxy_set_header  X-Real-IP  $remote_addr;
client_max_body_size  10m;
}
}

server {
 listen 80;
server_name o519.com  www.o519.com;
 
rewrite ^(.*)$ https://$host$1 permanent;
}
}
```