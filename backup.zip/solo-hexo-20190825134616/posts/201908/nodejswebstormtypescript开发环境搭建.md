title: nodejs+webstorm+typescript 开发环境搭建
date: '2019-08-13 13:35:28'
updated: '2019-08-13 14:53:18'
tags: [nodejs, Vditor]
permalink: /articles/2019/08/13/1565674528096.html
---
## Node.js
> 简单的说 Node.js 就是运行在服务端的 JavaScript。
Node.js 是一个基于Chrome JavaScript 运行时建立的一个平台。
Node.js是一个事件驱动I/O服务端JavaScript环境，基于Google的V8引擎，V8引擎执行Javascript的速度非常快，性能非常好。     ----[菜鸟教程](https://www.runoob.com/nodejs/nodejs-tutorial.html)


## NPM
> NPM是随同NodeJS一起安装的包管理工具，能解决NodeJS代码部署上的很多问题，常见的使用场景有以下几种：
> * 允许用户从NPM服务器下载别人编写的第三方包到本地使用。
> * 允许用户从NPM服务器下载并安装别人编写的命令行程序到本地使用。
> * 允许用户将自己编写的包或命令行程序上传到NPM服务器供别人使用。
由于新版的nodejs已经集成了npm，所以之前npm也一并安装好了。同样可以通过输入 "npm -v" 来测试是否成功安装。    ----[菜鸟教程-NPM 使用介绍](https://www.runoob.com/nodejs/nodejs-npm.html)

## 下载安装  
下载地址 http://nodejs.cn/download/  
中文API http://nodejs.cn/api/  
* npm配置  
修改全局安装模块位置及缓存位置，默认是C:\Users\xxx\AppData\Roaming\npm，新建node_global 以及node_cache文件夹，cmd执行如下命令

   ```  
   npm config set prefix "E:\nodejs\node_global"  
   npm config set cache "E:\nodejs\node_cache"  
   ```  
* 环境变量配置  
修改用户变量 **PATH=node_global文件夹所在位置**(原C:\Users\xxx\AppData\Roaming\npm)  
新建系统变量 **NODE_PATH=node_global文件夹所在位置/node_modules**
* 设置npm淘宝镜像 cmd执行
    ```
    设置镜像代理
    npm config set registry "https://registry.npm.taobao.org"  
    或者安装cnpm 取代npm
    npm install -g cnpm --registry= "https://registry.npm.taobao.org"
    或者设置服务器代理
    npm config set proxy http://server:port
    npm config set https-proxy http://server:port
    需要认证的话
    npm config set proxy http://username:password@server:port
    npm config set https-proxy http://username:pawword@server:port
    ```
* npm常用命令
```
    npm config get userconfig
    npm config get globalconfig
    npm init // 会自动生成一个package.json，管理依赖
    npm install express -g // 加-g，将包安装到全局环境中 默认会安装express的最新版本

    npm install express@3.0.6 // 指定版本安装
    npm install moduleName --save // 安装的同时，将安装的依赖信息写入package.json中  
    注：如果有package.json文件时，直接使用npm install方法就可以根据dependencies配置安装所有的依赖包，这样代码提交到远端时，就不用提交node_modules这个文件夹了。
    npm list // 查看当前目录下已安装的node包
    npm root -g // 查看node.js全局包的安装路径
    npm root // 查看当前项目npm包的安装路径
    npm outdated // 检查包是否已经过时，此命令会列出所有已经过时的包，可以及时进行包的更新
    npm update moduleName //更新node模块
    npm uninstall moudleName //卸载node模块
    npm -v //查看npm安装的版本
    npm config list //查看npm的设置  
    npm config delete proxy 删除代理，或是使用npm config edit编辑
    使用nrm管理registry：npm install -g nrm  
    nrm ls  
    nrm use cnpm     //switch registry to cnpm
    nrm help // show help 
    nrm list // show all registries 
    nrm home // go to a registry home page
```
* 测试 cmd执行
    ```
    npm install express -g
    ```
